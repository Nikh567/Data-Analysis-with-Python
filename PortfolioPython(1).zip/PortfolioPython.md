```python
import numpy as np, pandas as pd, matplotlib.pyplot as plt, seaborn as sns, os
```


```python
os.getcwd()
os.chdir('C:\\Users\\mycsv\\')
```


```python
dg=pd.read_csv('BigMartSalesData.csv')
dg
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>InvoiceNo</th>
      <th>StockCode</th>
      <th>Description</th>
      <th>Quantity</th>
      <th>UnitPrice</th>
      <th>Amount</th>
      <th>InvoiceDate</th>
      <th>Day</th>
      <th>Month</th>
      <th>Year</th>
      <th>CustomerID</th>
      <th>Country</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>536365</td>
      <td>85123A</td>
      <td>WHITE HANGING HEART T-LIGHT HOLDER</td>
      <td>6</td>
      <td>2.55</td>
      <td>15.30</td>
      <td>01-12-10</td>
      <td>1</td>
      <td>12</td>
      <td>2010</td>
      <td>17850.0</td>
      <td>United Kingdom</td>
    </tr>
    <tr>
      <th>1</th>
      <td>536365</td>
      <td>71053</td>
      <td>WHITE METAL LANTERN</td>
      <td>6</td>
      <td>3.39</td>
      <td>20.34</td>
      <td>01-12-10</td>
      <td>1</td>
      <td>12</td>
      <td>2010</td>
      <td>17850.0</td>
      <td>United Kingdom</td>
    </tr>
    <tr>
      <th>2</th>
      <td>536365</td>
      <td>84406B</td>
      <td>CREAM CUPID HEARTS COAT HANGER</td>
      <td>8</td>
      <td>2.75</td>
      <td>22.00</td>
      <td>01-12-10</td>
      <td>1</td>
      <td>12</td>
      <td>2010</td>
      <td>17850.0</td>
      <td>United Kingdom</td>
    </tr>
    <tr>
      <th>3</th>
      <td>536365</td>
      <td>84029G</td>
      <td>KNITTED UNION FLAG HOT WATER BOTTLE</td>
      <td>6</td>
      <td>3.39</td>
      <td>20.34</td>
      <td>01-12-10</td>
      <td>1</td>
      <td>12</td>
      <td>2010</td>
      <td>17850.0</td>
      <td>United Kingdom</td>
    </tr>
    <tr>
      <th>4</th>
      <td>536365</td>
      <td>84029E</td>
      <td>RED WOOLLY HOTTIE WHITE HEART.</td>
      <td>6</td>
      <td>3.39</td>
      <td>20.34</td>
      <td>01-12-10</td>
      <td>1</td>
      <td>12</td>
      <td>2010</td>
      <td>17850.0</td>
      <td>United Kingdom</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>541869</th>
      <td>581587</td>
      <td>22613</td>
      <td>PACK OF 20 SPACEBOY NAPKINS</td>
      <td>12</td>
      <td>0.85</td>
      <td>10.20</td>
      <td>09-12-11</td>
      <td>9</td>
      <td>12</td>
      <td>2011</td>
      <td>12680.0</td>
      <td>France</td>
    </tr>
    <tr>
      <th>541870</th>
      <td>581587</td>
      <td>22899</td>
      <td>CHILDREN'S APRON DOLLY GIRL</td>
      <td>6</td>
      <td>2.10</td>
      <td>12.60</td>
      <td>09-12-11</td>
      <td>9</td>
      <td>12</td>
      <td>2011</td>
      <td>12680.0</td>
      <td>France</td>
    </tr>
    <tr>
      <th>541871</th>
      <td>581587</td>
      <td>23254</td>
      <td>CHILDRENS CUTLERY DOLLY GIRL</td>
      <td>4</td>
      <td>4.15</td>
      <td>16.60</td>
      <td>09-12-11</td>
      <td>9</td>
      <td>12</td>
      <td>2011</td>
      <td>12680.0</td>
      <td>France</td>
    </tr>
    <tr>
      <th>541872</th>
      <td>581587</td>
      <td>23255</td>
      <td>CHILDRENS CUTLERY CIRCUS PARADE</td>
      <td>4</td>
      <td>4.15</td>
      <td>16.60</td>
      <td>09-12-11</td>
      <td>9</td>
      <td>12</td>
      <td>2011</td>
      <td>12680.0</td>
      <td>France</td>
    </tr>
    <tr>
      <th>541873</th>
      <td>581587</td>
      <td>22138</td>
      <td>BAKING SET 9 PIECE RETROSPOT</td>
      <td>3</td>
      <td>4.95</td>
      <td>14.85</td>
      <td>09-12-11</td>
      <td>9</td>
      <td>12</td>
      <td>2011</td>
      <td>12680.0</td>
      <td>France</td>
    </tr>
  </tbody>
</table>
<p>541874 rows × 12 columns</p>
</div>




```python
dg.describe(include='all')
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>InvoiceNo</th>
      <th>StockCode</th>
      <th>Description</th>
      <th>Quantity</th>
      <th>UnitPrice</th>
      <th>Amount</th>
      <th>InvoiceDate</th>
      <th>Day</th>
      <th>Month</th>
      <th>Year</th>
      <th>CustomerID</th>
      <th>Country</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>541874</td>
      <td>541874</td>
      <td>540422</td>
      <td>541874.000000</td>
      <td>541874.000000</td>
      <td>541874.000000</td>
      <td>541874</td>
      <td>541874.000000</td>
      <td>541874.000000</td>
      <td>541874.000000</td>
      <td>406829.000000</td>
      <td>541874</td>
    </tr>
    <tr>
      <th>unique</th>
      <td>25897</td>
      <td>4064</td>
      <td>4216</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>305</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>38</td>
    </tr>
    <tr>
      <th>top</th>
      <td>573585</td>
      <td>85123A</td>
      <td>WHITE HANGING HEART T-LIGHT HOLDER</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>05-12-11</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>United Kingdom</td>
    </tr>
    <tr>
      <th>freq</th>
      <td>1113</td>
      <td>2313</td>
      <td>2369</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>5331</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>495443</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>11.341028</td>
      <td>4.610038</td>
      <td>21.297578</td>
      <td>NaN</td>
      <td>15.022902</td>
      <td>7.553228</td>
      <td>2010.921607</td>
      <td>15287.690570</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>std</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>218.002505</td>
      <td>96.762800</td>
      <td>378.651364</td>
      <td>NaN</td>
      <td>8.663960</td>
      <td>3.509063</td>
      <td>0.268789</td>
      <td>1713.600303</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>min</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1.000000</td>
      <td>-11062.060000</td>
      <td>-11062.060000</td>
      <td>NaN</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>2010.000000</td>
      <td>12346.000000</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1.000000</td>
      <td>1.250000</td>
      <td>3.750000</td>
      <td>NaN</td>
      <td>7.000000</td>
      <td>5.000000</td>
      <td>2011.000000</td>
      <td>13953.000000</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>3.000000</td>
      <td>2.080000</td>
      <td>9.900000</td>
      <td>NaN</td>
      <td>15.000000</td>
      <td>8.000000</td>
      <td>2011.000000</td>
      <td>15152.000000</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>10.000000</td>
      <td>4.130000</td>
      <td>17.700000</td>
      <td>NaN</td>
      <td>22.000000</td>
      <td>11.000000</td>
      <td>2011.000000</td>
      <td>16791.000000</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>max</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>80995.000000</td>
      <td>38970.000000</td>
      <td>168469.600000</td>
      <td>NaN</td>
      <td>31.000000</td>
      <td>12.000000</td>
      <td>2011.000000</td>
      <td>18287.000000</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>




```python
dg.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 541874 entries, 0 to 541873
    Data columns (total 12 columns):
     #   Column       Non-Null Count   Dtype  
    ---  ------       --------------   -----  
     0   InvoiceNo    541874 non-null  object 
     1   StockCode    541874 non-null  object 
     2   Description  540422 non-null  object 
     3   Quantity     541874 non-null  int64  
     4   UnitPrice    541874 non-null  float64
     5   Amount       541874 non-null  float64
     6   InvoiceDate  541874 non-null  object 
     7   Day          541874 non-null  int64  
     8   Month        541874 non-null  int64  
     9   Year         541874 non-null  int64  
     10  CustomerID   406829 non-null  float64
     11  Country      541874 non-null  object 
    dtypes: float64(3), int64(4), object(5)
    memory usage: 49.6+ MB
    


```python
dg.isnull().any()
```




    InvoiceNo      False
    StockCode      False
    Description     True
    Quantity       False
    UnitPrice      False
    Amount         False
    InvoiceDate    False
    Day            False
    Month          False
    Year           False
    CustomerID      True
    Country        False
    dtype: bool




```python
dg.isnull().sum()
```




    InvoiceNo           0
    StockCode           0
    Description      1452
    Quantity            0
    UnitPrice           0
    Amount              0
    InvoiceDate         0
    Day                 0
    Month               0
    Year                0
    CustomerID     135045
    Country             0
    dtype: int64




```python
list(dg)
```




    ['InvoiceNo',
     'StockCode',
     'Description',
     'Quantity',
     'UnitPrice',
     'Amount',
     'InvoiceDate',
     'Day',
     'Month',
     'Year',
     'CustomerID',
     'Country']




```python
dg['InvoiceNo'].value_counts()
```




    573585    1113
    581219     749
    581492     731
    580729     721
    558475     705
              ... 
    569339       1
    562386       1
    575038       1
    570596       1
    547559       1
    Name: InvoiceNo, Length: 25897, dtype: int64




```python
dg['InvoiceNo'].head(10)
```




    0    536365
    1    536365
    2    536365
    3    536365
    4    536365
    5    536365
    6    536365
    7    536366
    8    536366
    9    536367
    Name: InvoiceNo, dtype: object




```python
dg['InvoiceNo'].describe()
```




    count     541874
    unique     25897
    top       573585
    freq        1113
    Name: InvoiceNo, dtype: object




```python
dg['InvoiceNo'].isna().sum()
```




    0




```python
dg['Description'].describe()
```




    count                                 540422
    unique                                  4216
    top       WHITE HANGING HEART T-LIGHT HOLDER
    freq                                    2369
    Name: Description, dtype: object




```python
dg['Description'].isnull().sum()
```




    1452




```python
dg.median()
```




    Quantity          3.00
    UnitPrice         2.08
    Amount            9.90
    Day              15.00
    Month             8.00
    Year           2011.00
    CustomerID    15152.00
    dtype: float64




```python
dg.shape
```




    (541874, 12)




```python
dg['Description'].unique()
```




    array(['WHITE HANGING HEART T-LIGHT HOLDER', 'WHITE METAL LANTERN',
           'CREAM CUPID HEARTS COAT HANGER', ..., 'lost',
           'CREAM HANGING HEART T-LIGHT HOLDER',
           'PAPER CRAFT , LITTLE BIRDIE'], dtype=object)




```python
dg['Description'].value_counts()
```




    WHITE HANGING HEART T-LIGHT HOLDER    2369
    REGENCY CAKESTAND 3 TIER              2200
    JUMBO BAG RED RETROSPOT               2159
    PARTY BUNTING                         1727
    LUNCH BAG RED RETROSPOT               1638
                                          ... 
    M/COLOUR POM-POM CURTAIN                 1
    Printing smudges/thrown away             1
    samples/damages                          1
    WRAP  PINK FLOCK                         1
    ZINC PLANT POT HOLDER                    1
    Name: Description, Length: 4216, dtype: int64




```python
type(dg)
```




    pandas.core.frame.DataFrame




```python
type(dg['InvoiceNo'])
```




    pandas.core.series.Series




```python
dg['InvoiceNo'].dtype
```




    dtype('O')




```python
dg['Amount'].dtype
```




    dtype('float64')




```python
dg['Quantity'].dtype
```




    dtype('int64')




```python
dg.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 541874 entries, 0 to 541873
    Data columns (total 12 columns):
     #   Column       Non-Null Count   Dtype  
    ---  ------       --------------   -----  
     0   InvoiceNo    541874 non-null  object 
     1   StockCode    541874 non-null  object 
     2   Description  540422 non-null  object 
     3   Quantity     541874 non-null  int64  
     4   UnitPrice    541874 non-null  float64
     5   Amount       541874 non-null  float64
     6   InvoiceDate  541874 non-null  object 
     7   Day          541874 non-null  int64  
     8   Month        541874 non-null  int64  
     9   Year         541874 non-null  int64  
     10  CustomerID   406829 non-null  float64
     11  Country      541874 non-null  object 
    dtypes: float64(3), int64(4), object(5)
    memory usage: 49.6+ MB
    


```python
dg['Day']=pd.to_datetime(dg['Day'])
dg['Month']=pd.to_datetime(dg['Month'])
dg['Year']=pd.to_datetime(dg['Year'])
```


```python
dg.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 541874 entries, 0 to 541873
    Data columns (total 12 columns):
     #   Column       Non-Null Count   Dtype         
    ---  ------       --------------   -----         
     0   InvoiceNo    541874 non-null  object        
     1   StockCode    541874 non-null  object        
     2   Description  540422 non-null  object        
     3   Quantity     541874 non-null  int64         
     4   UnitPrice    541874 non-null  float64       
     5   Amount       541874 non-null  float64       
     6   InvoiceDate  541874 non-null  object        
     7   Day          541874 non-null  datetime64[ns]
     8   Month        541874 non-null  datetime64[ns]
     9   Year         541874 non-null  datetime64[ns]
     10  CustomerID   406829 non-null  float64       
     11  Country      541874 non-null  object        
    dtypes: datetime64[ns](3), float64(3), int64(1), object(5)
    memory usage: 49.6+ MB
    


```python
dg['Description'].mode()
```




    0    WHITE HANGING HEART T-LIGHT HOLDER
    dtype: object




```python
dg.mode()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>InvoiceNo</th>
      <th>StockCode</th>
      <th>Description</th>
      <th>Quantity</th>
      <th>UnitPrice</th>
      <th>Amount</th>
      <th>InvoiceDate</th>
      <th>Day</th>
      <th>Month</th>
      <th>Year</th>
      <th>CustomerID</th>
      <th>Country</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>573585</td>
      <td>85123A</td>
      <td>WHITE HANGING HEART T-LIGHT HOLDER</td>
      <td>1</td>
      <td>1.25</td>
      <td>15.0</td>
      <td>05-12-11</td>
      <td>1970-01-01 00:00:00.000000008</td>
      <td>1970-01-01 00:00:00.000000011</td>
      <td>1970-01-01 00:00:00.000002011</td>
      <td>17841.0</td>
      <td>United Kingdom</td>
    </tr>
  </tbody>
</table>
</div>




```python
dg['Description'].iloc[0]
```




    'WHITE HANGING HEART T-LIGHT HOLDER'




```python
dg['Description'].fillna(dg['Description'].mode().iloc[0],inplace=True)
```


```python
dg['Description'].isnull().sum()
```




    0




```python
dg.isnull().sum()
```




    InvoiceNo           0
    StockCode           0
    Description         0
    Quantity            0
    UnitPrice           0
    Amount              0
    InvoiceDate         0
    Day                 0
    Month               0
    Year                0
    CustomerID     135045
    Country             0
    dtype: int64




```python
dg['CustomerID'].dtype
```




    dtype('float64')




```python
dg['CustomerID'].value_counts()
```




    17841.0    7983
    14911.0    5903
    14096.0    5128
    12748.0    4642
    14606.0    2782
               ... 
    14351.0       1
    13256.0       1
    12943.0       1
    17923.0       1
    13747.0       1
    Name: CustomerID, Length: 4372, dtype: int64




```python
dg['CustomerID'].mean()
```




    15287.690570239585




```python
dg['CustomerID'].fillna(dg['CustomerID'].mean(),inplace=True)
```


```python
dg['CustomerID'].isnull().sum()
```




    0




```python
dg.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 541874 entries, 0 to 541873
    Data columns (total 12 columns):
     #   Column       Non-Null Count   Dtype         
    ---  ------       --------------   -----         
     0   InvoiceNo    541874 non-null  object        
     1   StockCode    541874 non-null  object        
     2   Description  541874 non-null  object        
     3   Quantity     541874 non-null  int64         
     4   UnitPrice    541874 non-null  float64       
     5   Amount       541874 non-null  float64       
     6   InvoiceDate  541874 non-null  object        
     7   Day          541874 non-null  datetime64[ns]
     8   Month        541874 non-null  datetime64[ns]
     9   Year         541874 non-null  datetime64[ns]
     10  CustomerID   541874 non-null  float64       
     11  Country      541874 non-null  object        
    dtypes: datetime64[ns](3), float64(3), int64(1), object(5)
    memory usage: 49.6+ MB
    


```python
dg[dg.duplicated()]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>InvoiceNo</th>
      <th>StockCode</th>
      <th>Description</th>
      <th>Quantity</th>
      <th>UnitPrice</th>
      <th>Amount</th>
      <th>InvoiceDate</th>
      <th>Day</th>
      <th>Month</th>
      <th>Year</th>
      <th>CustomerID</th>
      <th>Country</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>517</th>
      <td>536409</td>
      <td>21866</td>
      <td>UNION JACK FLAG LUGGAGE TAG</td>
      <td>1</td>
      <td>1.25</td>
      <td>1.25</td>
      <td>01-12-10</td>
      <td>1970-01-01 00:00:00.000000001</td>
      <td>1970-01-01 00:00:00.000000012</td>
      <td>1970-01-01 00:00:00.000002010</td>
      <td>17908.0</td>
      <td>United Kingdom</td>
    </tr>
    <tr>
      <th>527</th>
      <td>536409</td>
      <td>22866</td>
      <td>HAND WARMER SCOTTY DOG DESIGN</td>
      <td>1</td>
      <td>2.10</td>
      <td>2.10</td>
      <td>01-12-10</td>
      <td>1970-01-01 00:00:00.000000001</td>
      <td>1970-01-01 00:00:00.000000012</td>
      <td>1970-01-01 00:00:00.000002010</td>
      <td>17908.0</td>
      <td>United Kingdom</td>
    </tr>
    <tr>
      <th>537</th>
      <td>536409</td>
      <td>22900</td>
      <td>SET 2 TEA TOWELS I LOVE LONDON</td>
      <td>1</td>
      <td>2.95</td>
      <td>2.95</td>
      <td>01-12-10</td>
      <td>1970-01-01 00:00:00.000000001</td>
      <td>1970-01-01 00:00:00.000000012</td>
      <td>1970-01-01 00:00:00.000002010</td>
      <td>17908.0</td>
      <td>United Kingdom</td>
    </tr>
    <tr>
      <th>539</th>
      <td>536409</td>
      <td>22111</td>
      <td>SCOTTIE DOG HOT WATER BOTTLE</td>
      <td>1</td>
      <td>4.95</td>
      <td>4.95</td>
      <td>01-12-10</td>
      <td>1970-01-01 00:00:00.000000001</td>
      <td>1970-01-01 00:00:00.000000012</td>
      <td>1970-01-01 00:00:00.000002010</td>
      <td>17908.0</td>
      <td>United Kingdom</td>
    </tr>
    <tr>
      <th>555</th>
      <td>536412</td>
      <td>22327</td>
      <td>ROUND SNACK BOXES SET OF 4 SKULLS</td>
      <td>1</td>
      <td>2.95</td>
      <td>2.95</td>
      <td>01-12-10</td>
      <td>1970-01-01 00:00:00.000000001</td>
      <td>1970-01-01 00:00:00.000000012</td>
      <td>1970-01-01 00:00:00.000002010</td>
      <td>17920.0</td>
      <td>United Kingdom</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>541640</th>
      <td>581538</td>
      <td>22068</td>
      <td>BLACK PIRATE TREASURE CHEST</td>
      <td>1</td>
      <td>0.39</td>
      <td>0.39</td>
      <td>09-12-11</td>
      <td>1970-01-01 00:00:00.000000009</td>
      <td>1970-01-01 00:00:00.000000012</td>
      <td>1970-01-01 00:00:00.000002011</td>
      <td>14446.0</td>
      <td>United Kingdom</td>
    </tr>
    <tr>
      <th>541654</th>
      <td>581538</td>
      <td>23318</td>
      <td>BOX OF 6 MINI VINTAGE CRACKERS</td>
      <td>1</td>
      <td>2.49</td>
      <td>2.49</td>
      <td>09-12-11</td>
      <td>1970-01-01 00:00:00.000000009</td>
      <td>1970-01-01 00:00:00.000000012</td>
      <td>1970-01-01 00:00:00.000002011</td>
      <td>14446.0</td>
      <td>United Kingdom</td>
    </tr>
    <tr>
      <th>541657</th>
      <td>581538</td>
      <td>22992</td>
      <td>REVOLVER WOODEN RULER</td>
      <td>1</td>
      <td>1.95</td>
      <td>1.95</td>
      <td>09-12-11</td>
      <td>1970-01-01 00:00:00.000000009</td>
      <td>1970-01-01 00:00:00.000000012</td>
      <td>1970-01-01 00:00:00.000002011</td>
      <td>14446.0</td>
      <td>United Kingdom</td>
    </tr>
    <tr>
      <th>541664</th>
      <td>581538</td>
      <td>22694</td>
      <td>WICKER STAR</td>
      <td>1</td>
      <td>2.10</td>
      <td>2.10</td>
      <td>09-12-11</td>
      <td>1970-01-01 00:00:00.000000009</td>
      <td>1970-01-01 00:00:00.000000012</td>
      <td>1970-01-01 00:00:00.000002011</td>
      <td>14446.0</td>
      <td>United Kingdom</td>
    </tr>
    <tr>
      <th>541666</th>
      <td>581538</td>
      <td>23343</td>
      <td>JUMBO BAG VINTAGE CHRISTMAS</td>
      <td>1</td>
      <td>2.08</td>
      <td>2.08</td>
      <td>09-12-11</td>
      <td>1970-01-01 00:00:00.000000009</td>
      <td>1970-01-01 00:00:00.000000012</td>
      <td>1970-01-01 00:00:00.000002011</td>
      <td>14446.0</td>
      <td>United Kingdom</td>
    </tr>
  </tbody>
</table>
<p>5269 rows × 12 columns</p>
</div>




```python
dg_corr=dg.corr()
```


```python
dg_corr
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Quantity</th>
      <th>UnitPrice</th>
      <th>Amount</th>
      <th>CustomerID</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Quantity</th>
      <td>1.000000</td>
      <td>-0.001469</td>
      <td>0.886587</td>
      <td>-0.005041</td>
    </tr>
    <tr>
      <th>UnitPrice</th>
      <td>-0.001469</td>
      <td>1.000000</td>
      <td>0.257257</td>
      <td>-0.002830</td>
    </tr>
    <tr>
      <th>Amount</th>
      <td>0.886587</td>
      <td>0.257257</td>
      <td>1.000000</td>
      <td>-0.003064</td>
    </tr>
    <tr>
      <th>CustomerID</th>
      <td>-0.005041</td>
      <td>-0.002830</td>
      <td>-0.003064</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
plt.figure(dpi=135,facecolor='violet')
sns.heatmap(dg_corr,annot=True)
```




    <AxesSubplot:>




    
![png](output_41_1.png)
    



```python
dg[dg.loc[:,'Quantity']>500]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>InvoiceNo</th>
      <th>StockCode</th>
      <th>Description</th>
      <th>Quantity</th>
      <th>UnitPrice</th>
      <th>Amount</th>
      <th>InvoiceDate</th>
      <th>Day</th>
      <th>Month</th>
      <th>Year</th>
      <th>CustomerID</th>
      <th>Country</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>730</th>
      <td>536437</td>
      <td>17021</td>
      <td>NAMASTE SWAGAT INCENSE</td>
      <td>600</td>
      <td>0.24</td>
      <td>144.0</td>
      <td>01-12-10</td>
      <td>1970-01-01 00:00:00.000000001</td>
      <td>1970-01-01 00:00:00.000000012</td>
      <td>1970-01-01 00:00:00.000002010</td>
      <td>13694.0</td>
      <td>United Kingdom</td>
    </tr>
    <tr>
      <th>3917</th>
      <td>536736</td>
      <td>22616</td>
      <td>PACK OF 12 LONDON TISSUES</td>
      <td>600</td>
      <td>0.29</td>
      <td>174.0</td>
      <td>02-12-10</td>
      <td>1970-01-01 00:00:00.000000002</td>
      <td>1970-01-01 00:00:00.000000012</td>
      <td>1970-01-01 00:00:00.000002010</td>
      <td>17381.0</td>
      <td>United Kingdom</td>
    </tr>
    <tr>
      <th>4287</th>
      <td>C536757</td>
      <td>84347</td>
      <td>ROTATING SILVER ANGELS T-LIGHT HLDR</td>
      <td>9360</td>
      <td>0.03</td>
      <td>280.8</td>
      <td>02-12-10</td>
      <td>1970-01-01 00:00:00.000000002</td>
      <td>1970-01-01 00:00:00.000000012</td>
      <td>1970-01-01 00:00:00.000002010</td>
      <td>15838.0</td>
      <td>United Kingdom</td>
    </tr>
    <tr>
      <th>4850</th>
      <td>536809</td>
      <td>84950</td>
      <td>ASSORTED COLOUR T-LIGHT HOLDER</td>
      <td>1824</td>
      <td>0.55</td>
      <td>1003.2</td>
      <td>02-12-10</td>
      <td>1970-01-01 00:00:00.000000002</td>
      <td>1970-01-01 00:00:00.000000012</td>
      <td>1970-01-01 00:00:00.000002010</td>
      <td>15299.0</td>
      <td>United Kingdom</td>
    </tr>
    <tr>
      <th>4945</th>
      <td>536830</td>
      <td>84077</td>
      <td>WORLD WAR 2 GLIDERS ASSTD DESIGNS</td>
      <td>2880</td>
      <td>0.18</td>
      <td>518.4</td>
      <td>02-12-10</td>
      <td>1970-01-01 00:00:00.000000002</td>
      <td>1970-01-01 00:00:00.000000012</td>
      <td>1970-01-01 00:00:00.000002010</td>
      <td>16754.0</td>
      <td>United Kingdom</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>540026</th>
      <td>581457</td>
      <td>23543</td>
      <td>WALL ART KEEP CALM</td>
      <td>698</td>
      <td>4.15</td>
      <td>2896.7</td>
      <td>08-12-11</td>
      <td>1970-01-01 00:00:00.000000008</td>
      <td>1970-01-01 00:00:00.000000012</td>
      <td>1970-01-01 00:00:00.000002011</td>
      <td>18102.0</td>
      <td>United Kingdom</td>
    </tr>
    <tr>
      <th>540035</th>
      <td>581458</td>
      <td>22197</td>
      <td>POPCORN HOLDER</td>
      <td>1500</td>
      <td>0.72</td>
      <td>1080.0</td>
      <td>08-12-11</td>
      <td>1970-01-01 00:00:00.000000008</td>
      <td>1970-01-01 00:00:00.000000012</td>
      <td>1970-01-01 00:00:00.000002011</td>
      <td>17949.0</td>
      <td>United Kingdom</td>
    </tr>
    <tr>
      <th>540036</th>
      <td>581459</td>
      <td>22197</td>
      <td>POPCORN HOLDER</td>
      <td>1200</td>
      <td>0.72</td>
      <td>864.0</td>
      <td>08-12-11</td>
      <td>1970-01-01 00:00:00.000000008</td>
      <td>1970-01-01 00:00:00.000000012</td>
      <td>1970-01-01 00:00:00.000002011</td>
      <td>17949.0</td>
      <td>United Kingdom</td>
    </tr>
    <tr>
      <th>540386</th>
      <td>581483</td>
      <td>23843</td>
      <td>PAPER CRAFT , LITTLE BIRDIE</td>
      <td>80995</td>
      <td>2.08</td>
      <td>168469.6</td>
      <td>09-12-11</td>
      <td>1970-01-01 00:00:00.000000009</td>
      <td>1970-01-01 00:00:00.000000012</td>
      <td>1970-01-01 00:00:00.000002011</td>
      <td>16446.0</td>
      <td>United Kingdom</td>
    </tr>
    <tr>
      <th>540387</th>
      <td>C581484</td>
      <td>23843</td>
      <td>PAPER CRAFT , LITTLE BIRDIE</td>
      <td>80995</td>
      <td>2.08</td>
      <td>168469.6</td>
      <td>09-12-11</td>
      <td>1970-01-01 00:00:00.000000009</td>
      <td>1970-01-01 00:00:00.000000012</td>
      <td>1970-01-01 00:00:00.000002011</td>
      <td>16446.0</td>
      <td>United Kingdom</td>
    </tr>
  </tbody>
</table>
<p>542 rows × 12 columns</p>
</div>




```python
dg[['Amount']].tail(20)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Amount</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>541854</th>
      <td>23.40</td>
    </tr>
    <tr>
      <th>541855</th>
      <td>23.60</td>
    </tr>
    <tr>
      <th>541856</th>
      <td>30.00</td>
    </tr>
    <tr>
      <th>541857</th>
      <td>214.80</td>
    </tr>
    <tr>
      <th>541858</th>
      <td>70.80</td>
    </tr>
    <tr>
      <th>541859</th>
      <td>23.40</td>
    </tr>
    <tr>
      <th>541860</th>
      <td>19.80</td>
    </tr>
    <tr>
      <th>541861</th>
      <td>19.80</td>
    </tr>
    <tr>
      <th>541862</th>
      <td>15.00</td>
    </tr>
    <tr>
      <th>541863</th>
      <td>15.00</td>
    </tr>
    <tr>
      <th>541864</th>
      <td>15.00</td>
    </tr>
    <tr>
      <th>541865</th>
      <td>15.00</td>
    </tr>
    <tr>
      <th>541866</th>
      <td>15.60</td>
    </tr>
    <tr>
      <th>541867</th>
      <td>23.40</td>
    </tr>
    <tr>
      <th>541868</th>
      <td>16.60</td>
    </tr>
    <tr>
      <th>541869</th>
      <td>10.20</td>
    </tr>
    <tr>
      <th>541870</th>
      <td>12.60</td>
    </tr>
    <tr>
      <th>541871</th>
      <td>16.60</td>
    </tr>
    <tr>
      <th>541872</th>
      <td>16.60</td>
    </tr>
    <tr>
      <th>541873</th>
      <td>14.85</td>
    </tr>
  </tbody>
</table>
</div>




```python
dg2=sum(dg.loc[:,'Amount'])
```


```python
dg2
```




    11540603.774004437




```python
dg2=dg.loc[:,['Amount','Quantity']]
dg2
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Amount</th>
      <th>Quantity</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>15.30</td>
      <td>6</td>
    </tr>
    <tr>
      <th>1</th>
      <td>20.34</td>
      <td>6</td>
    </tr>
    <tr>
      <th>2</th>
      <td>22.00</td>
      <td>8</td>
    </tr>
    <tr>
      <th>3</th>
      <td>20.34</td>
      <td>6</td>
    </tr>
    <tr>
      <th>4</th>
      <td>20.34</td>
      <td>6</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>541869</th>
      <td>10.20</td>
      <td>12</td>
    </tr>
    <tr>
      <th>541870</th>
      <td>12.60</td>
      <td>6</td>
    </tr>
    <tr>
      <th>541871</th>
      <td>16.60</td>
      <td>4</td>
    </tr>
    <tr>
      <th>541872</th>
      <td>16.60</td>
      <td>4</td>
    </tr>
    <tr>
      <th>541873</th>
      <td>14.85</td>
      <td>3</td>
    </tr>
  </tbody>
</table>
<p>541874 rows × 2 columns</p>
</div>




```python
df=pd.read_csv('HollywoodMovies.csv')
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Movie</th>
      <th>LeadStudio</th>
      <th>RottenTomatoes</th>
      <th>AudienceScore</th>
      <th>Story</th>
      <th>Genre</th>
      <th>TheatersOpenWeek</th>
      <th>OpeningWeekend</th>
      <th>BOAvgOpenWeekend</th>
      <th>DomesticGross</th>
      <th>ForeignGross</th>
      <th>WorldGross</th>
      <th>Budget</th>
      <th>Profitability</th>
      <th>OpenProfit</th>
      <th>Year</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Spider-Man 3</td>
      <td>Sony</td>
      <td>61.0</td>
      <td>54.0</td>
      <td>Metamorphosis</td>
      <td>Action</td>
      <td>4252.0</td>
      <td>151.10</td>
      <td>35540.0</td>
      <td>336.53</td>
      <td>554.34</td>
      <td>890.87</td>
      <td>258.0</td>
      <td>345.30</td>
      <td>58.57</td>
      <td>2007</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Shrek the Third</td>
      <td>Paramount</td>
      <td>42.0</td>
      <td>57.0</td>
      <td>Quest</td>
      <td>Animation</td>
      <td>4122.0</td>
      <td>121.60</td>
      <td>29507.0</td>
      <td>322.72</td>
      <td>476.24</td>
      <td>798.96</td>
      <td>160.0</td>
      <td>499.35</td>
      <td>76.00</td>
      <td>2007</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Transformers</td>
      <td>Paramount</td>
      <td>57.0</td>
      <td>89.0</td>
      <td>Monster Force</td>
      <td>Action</td>
      <td>4011.0</td>
      <td>70.50</td>
      <td>17577.0</td>
      <td>319.25</td>
      <td>390.46</td>
      <td>709.71</td>
      <td>150.0</td>
      <td>473.14</td>
      <td>47.00</td>
      <td>2007</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Pirates of the Caribbean: At World's End</td>
      <td>Disney</td>
      <td>45.0</td>
      <td>74.0</td>
      <td>Rescue</td>
      <td>Action</td>
      <td>4362.0</td>
      <td>114.70</td>
      <td>26302.0</td>
      <td>309.42</td>
      <td>654.00</td>
      <td>963.42</td>
      <td>300.0</td>
      <td>321.14</td>
      <td>38.23</td>
      <td>2007</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Harry Potter and the Order of the Phoenix</td>
      <td>Warner Bros</td>
      <td>78.0</td>
      <td>82.0</td>
      <td>Quest</td>
      <td>Adventure</td>
      <td>4285.0</td>
      <td>77.10</td>
      <td>17998.0</td>
      <td>292.00</td>
      <td>647.88</td>
      <td>939.89</td>
      <td>150.0</td>
      <td>626.59</td>
      <td>51.40</td>
      <td>2007</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>965</th>
      <td>The Canyons</td>
      <td>IFC</td>
      <td>22.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1.0</td>
      <td>0.01</td>
      <td>13351.0</td>
      <td>0.06</td>
      <td>0.14</td>
      <td>0.19</td>
      <td>NaN</td>
      <td>77.21</td>
      <td>NaN</td>
      <td>2013</td>
    </tr>
    <tr>
      <th>966</th>
      <td>The Call</td>
      <td>TriStar</td>
      <td>43.0</td>
      <td>66.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2507.0</td>
      <td>17.12</td>
      <td>6828.0</td>
      <td>51.87</td>
      <td>16.70</td>
      <td>68.57</td>
      <td>13.0</td>
      <td>527.48</td>
      <td>131.69</td>
      <td>2013</td>
    </tr>
    <tr>
      <th>967</th>
      <td>The English Teacher</td>
      <td>Cinedigm Entertainment</td>
      <td>42.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2.0</td>
      <td>0.01</td>
      <td>3001.0</td>
      <td>0.10</td>
      <td>0.06</td>
      <td>0.10</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2013</td>
    </tr>
    <tr>
      <th>968</th>
      <td>John Dies at the End</td>
      <td>Magnolia</td>
      <td>61.0</td>
      <td>53.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1.0</td>
      <td>0.01</td>
      <td>12467.0</td>
      <td>0.14</td>
      <td>NaN</td>
      <td>0.14</td>
      <td>1.0</td>
      <td>14.20</td>
      <td>1.00</td>
      <td>2013</td>
    </tr>
    <tr>
      <th>969</th>
      <td>Lovelace</td>
      <td>Radius-TWC</td>
      <td>55.0</td>
      <td>37.0</td>
      <td>NaN</td>
      <td>Biography</td>
      <td>118.0</td>
      <td>0.18</td>
      <td>1564.0</td>
      <td>0.36</td>
      <td>1.17</td>
      <td>1.52</td>
      <td>10.0</td>
      <td>15.25</td>
      <td>1.80</td>
      <td>2013</td>
    </tr>
  </tbody>
</table>
<p>970 rows × 16 columns</p>
</div>




```python
df.isnull().any()
```




    Movie               False
    LeadStudio           True
    RottenTomatoes       True
    AudienceScore        True
    Story                True
    Genre                True
    TheatersOpenWeek     True
    OpeningWeekend       True
    BOAvgOpenWeekend     True
    DomesticGross       False
    ForeignGross         True
    WorldGross           True
    Budget               True
    Profitability        True
    OpenProfit           True
    Year                False
    dtype: bool




```python
df[df['LeadStudio'].isnull()]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Movie</th>
      <th>LeadStudio</th>
      <th>RottenTomatoes</th>
      <th>AudienceScore</th>
      <th>Story</th>
      <th>Genre</th>
      <th>TheatersOpenWeek</th>
      <th>OpeningWeekend</th>
      <th>BOAvgOpenWeekend</th>
      <th>DomesticGross</th>
      <th>ForeignGross</th>
      <th>WorldGross</th>
      <th>Budget</th>
      <th>Profitability</th>
      <th>OpenProfit</th>
      <th>Year</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>42</th>
      <td>TMNT</td>
      <td>NaN</td>
      <td>33.0</td>
      <td>63.0</td>
      <td>Monster Force</td>
      <td>Action</td>
      <td>3110.0</td>
      <td>24.30</td>
      <td>7799.0</td>
      <td>54.15</td>
      <td>41.46</td>
      <td>95.610</td>
      <td>35.0</td>
      <td>273.17</td>
      <td>69.43</td>
      <td>2007</td>
    </tr>
    <tr>
      <th>49</th>
      <td>The Kingdom</td>
      <td>NaN</td>
      <td>52.0</td>
      <td>78.0</td>
      <td>Quest</td>
      <td>Action</td>
      <td>2793.0</td>
      <td>17.10</td>
      <td>6135.0</td>
      <td>47.54</td>
      <td>39.12</td>
      <td>86.660</td>
      <td>80.0</td>
      <td>108.32</td>
      <td>21.38</td>
      <td>2007</td>
    </tr>
    <tr>
      <th>52</th>
      <td>No Reservations</td>
      <td>NaN</td>
      <td>39.0</td>
      <td>64.0</td>
      <td>Love</td>
      <td>Comedy</td>
      <td>2425.0</td>
      <td>11.70</td>
      <td>4826.0</td>
      <td>43.11</td>
      <td>49.49</td>
      <td>92.600</td>
      <td>28.0</td>
      <td>330.71</td>
      <td>41.79</td>
      <td>2007</td>
    </tr>
    <tr>
      <th>59</th>
      <td>The Brave One</td>
      <td>NaN</td>
      <td>43.0</td>
      <td>65.0</td>
      <td>Rivalry</td>
      <td>Action</td>
      <td>2755.0</td>
      <td>13.50</td>
      <td>4889.0</td>
      <td>36.79</td>
      <td>32.99</td>
      <td>69.790</td>
      <td>70.0</td>
      <td>99.69</td>
      <td>19.29</td>
      <td>2007</td>
    </tr>
    <tr>
      <th>70</th>
      <td>The Reaping</td>
      <td>NaN</td>
      <td>9.0</td>
      <td>53.0</td>
      <td>Quest</td>
      <td>Horror</td>
      <td>2603.0</td>
      <td>10.00</td>
      <td>3851.0</td>
      <td>25.13</td>
      <td>37.64</td>
      <td>62.770</td>
      <td>40.0</td>
      <td>156.93</td>
      <td>25.00</td>
      <td>2007</td>
    </tr>
    <tr>
      <th>90</th>
      <td>Pathfinder: Legend of the Ghost Warrior</td>
      <td>NaN</td>
      <td>11.0</td>
      <td>41.0</td>
      <td>Rescue</td>
      <td>Action</td>
      <td>1720.0</td>
      <td>5.00</td>
      <td>2907.0</td>
      <td>10.23</td>
      <td>20.59</td>
      <td>30.820</td>
      <td>26.0</td>
      <td>118.55</td>
      <td>19.23</td>
      <td>2007</td>
    </tr>
    <tr>
      <th>237</th>
      <td>Expelled: No Intelligence Allowed</td>
      <td>NaN</td>
      <td>10.0</td>
      <td>42.0</td>
      <td>comedy</td>
      <td>Documentary</td>
      <td>1052.0</td>
      <td>2.97</td>
      <td>2824.0</td>
      <td>7.72</td>
      <td>NaN</td>
      <td>7.720</td>
      <td>3.5</td>
      <td>220.57</td>
      <td>84.86</td>
      <td>2008</td>
    </tr>
    <tr>
      <th>508</th>
      <td>Yogi Bear</td>
      <td>NaN</td>
      <td>14.0</td>
      <td>36.0</td>
      <td>NaN</td>
      <td>Comedy</td>
      <td>3515.0</td>
      <td>16.40</td>
      <td>4669.0</td>
      <td>100.25</td>
      <td>101.34</td>
      <td>201.584</td>
      <td>80.0</td>
      <td>251.98</td>
      <td>20.50</td>
      <td>2010</td>
    </tr>
    <tr>
      <th>522</th>
      <td>Average</td>
      <td>NaN</td>
      <td>55.0</td>
      <td>62.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2733.0</td>
      <td>22.00</td>
      <td>8502.0</td>
      <td>69.00</td>
      <td>110.00</td>
      <td>175.000</td>
      <td>57.0</td>
      <td>306.60</td>
      <td>38.60</td>
      <td>2011</td>
    </tr>
  </tbody>
</table>
</div>




```python
df[['LeadStudio']]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>LeadStudio</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Sony</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Paramount</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Paramount</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Disney</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Warner Bros</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
    </tr>
    <tr>
      <th>965</th>
      <td>IFC</td>
    </tr>
    <tr>
      <th>966</th>
      <td>TriStar</td>
    </tr>
    <tr>
      <th>967</th>
      <td>Cinedigm Entertainment</td>
    </tr>
    <tr>
      <th>968</th>
      <td>Magnolia</td>
    </tr>
    <tr>
      <th>969</th>
      <td>Radius-TWC</td>
    </tr>
  </tbody>
</table>
<p>970 rows × 1 columns</p>
</div>




```python
df['LeadStudio'].mode()
```




    0    Independent
    dtype: object




```python
df['LeadStudio'].value_counts()
```




    Independent                 133
    Warner Bros                 114
    Sony                         98
    Fox                          91
    Universal                    85
    Paramount                    81
    Lionsgate                    40
    Weinstein                    39
    Disney                       39
    Summit                       33
    Relativity Media             30
    Buena Vista                  20
    Focus                        17
    Fox Searchlight              13
    CBS                          12
    Roadside Attractions          8
    DreamWorks                    8
    Open Road                     8
    FilmDistrict                  7
    IFC                           6
    Magnolia                      6
    TriStar                       6
    MGM                           5
    Eros                          4
    Miramax                       4
    Samuel Goldwyn                3
    A24                           3
    Spyglass Entertainment        3
    New Line                      3
    Happy Madison                 3
    Columbia                      3
    Screen Gems                   3
    LD Entertainment              2
    Legendary Pictures            2
    Yash Raj                      2
    ARC Entertainment             2
    Reliance                      2
    Liberty Starz                 2
    UTV                           1
    Cohen Media                   1
    Cinedigm Entertainment        1
    Mediaplex                     1
    Rocky Mountain                1
    Radius-TWC                    1
    Pixar                         1
    Village Roadshow              1
    Crest                         1
    Virgin                        1
    Overture                      1
    Highlight Communications      1
    Aardman Animations            1
    Millenium Entertainment       1
    Atlas Distribution            1
    Morgan Creek                  1
    Entertainment One             1
    Vertigo                       1
    Music Box Films               1
    Oscillloscope                 1
    Regency Enterprises           1
    Name: LeadStudio, dtype: int64




```python
df['LeadStudio'].fillna(df['LeadStudio'].mode().loc[0],inplace=True)
```


```python
df['LeadStudio'].isnull().any()
```




    False




```python
df.isnull().sum()
```




    Movie                 0
    LeadStudio            0
    RottenTomatoes       57
    AudienceScore        63
    Story               329
    Genre               279
    TheatersOpenWeek     21
    OpeningWeekend        1
    BOAvgOpenWeekend     25
    DomesticGross         0
    ForeignGross         94
    WorldGross           56
    Budget               73
    Profitability        74
    OpenProfit           75
    Year                  0
    dtype: int64




```python
df['RottenTomatoes'].mean()
```




    51.707557502738226




```python
df['RottenTomatoes'].isnull().sum()
```




    57




```python
df['RottenTomatoes'].fillna(df['RottenTomatoes'].median(),inplace=True)
```


```python
df['Story'].fillna(df['Story'].mode().loc[0],inplace=True)
```


```python
df.isnull().sum()
```




    Movie                 0
    LeadStudio            0
    RottenTomatoes        0
    AudienceScore        63
    Story                 0
    Genre               279
    TheatersOpenWeek     21
    OpeningWeekend        1
    BOAvgOpenWeekend     25
    DomesticGross         0
    ForeignGross         94
    WorldGross           56
    Budget               73
    Profitability        74
    OpenProfit           75
    Year                  0
    dtype: int64




```python
df['Genre'].fillna(df['Genre'].mode().loc[0],inplace=True)
```


```python
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 970 entries, 0 to 969
    Data columns (total 16 columns):
     #   Column            Non-Null Count  Dtype  
    ---  ------            --------------  -----  
     0   Movie             970 non-null    object 
     1   LeadStudio        970 non-null    object 
     2   RottenTomatoes    970 non-null    float64
     3   AudienceScore     907 non-null    float64
     4   Story             970 non-null    object 
     5   Genre             970 non-null    object 
     6   TheatersOpenWeek  949 non-null    float64
     7   OpeningWeekend    969 non-null    float64
     8   BOAvgOpenWeekend  945 non-null    float64
     9   DomesticGross     970 non-null    float64
     10  ForeignGross      876 non-null    float64
     11  WorldGross        914 non-null    float64
     12  Budget            897 non-null    float64
     13  Profitability     896 non-null    float64
     14  OpenProfit        895 non-null    float64
     15  Year              970 non-null    int64  
    dtypes: float64(11), int64(1), object(4)
    memory usage: 121.4+ KB
    


```python
df[df['ForeignGross']==0]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Movie</th>
      <th>LeadStudio</th>
      <th>RottenTomatoes</th>
      <th>AudienceScore</th>
      <th>Story</th>
      <th>Genre</th>
      <th>TheatersOpenWeek</th>
      <th>OpeningWeekend</th>
      <th>BOAvgOpenWeekend</th>
      <th>DomesticGross</th>
      <th>ForeignGross</th>
      <th>WorldGross</th>
      <th>Budget</th>
      <th>Profitability</th>
      <th>OpenProfit</th>
      <th>Year</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>895</th>
      <td>Safe Haven</td>
      <td>Relativity Media</td>
      <td>12.0</td>
      <td>68.0</td>
      <td>Comedy</td>
      <td>Comedy</td>
      <td>3223.0</td>
      <td>21.40</td>
      <td>6640.0</td>
      <td>71.35</td>
      <td>0.0</td>
      <td>71.35</td>
      <td>28.0</td>
      <td>254.82</td>
      <td>76.43</td>
      <td>2013</td>
    </tr>
    <tr>
      <th>932</th>
      <td>Admission</td>
      <td>Focus</td>
      <td>38.0</td>
      <td>34.0</td>
      <td>Comedy</td>
      <td>Comedy</td>
      <td>2161.0</td>
      <td>6.15</td>
      <td>2848.0</td>
      <td>18.01</td>
      <td>0.0</td>
      <td>18.01</td>
      <td>13.0</td>
      <td>138.52</td>
      <td>47.31</td>
      <td>2013</td>
    </tr>
  </tbody>
</table>
</div>




```python
df['ForeignGross'].fillna(df['ForeignGross'].mean(),inplace=True)
df['AudienceScore'].fillna(df['AudienceScore'].median(),inplace=True)
df['TheatersOpenWeek'].fillna(df['TheatersOpenWeek'].mean(),inplace=True)
df['OpeningWeekend'].fillna(df['OpeningWeekend'].median(),inplace=True)
df['BOAvgOpenWeekend'].fillna(df['BOAvgOpenWeekend'].mean(),inplace=True)
df['WorldGross'].fillna(df['WorldGross'].median(),inplace=True)
df['Budget'].fillna(df['Budget'].mean(),inplace=True)
df['Profitability'].fillna(df['Profitability'].mean(),inplace=True)
df['OpenProfit'].fillna(df['OpenProfit'].mean(),inplace=True)
```


```python
df['OpenProfit']
```




    0       58.570000
    1       76.000000
    2       47.000000
    3       38.230000
    4       51.400000
              ...    
    965     62.223575
    966    131.690000
    967     62.223575
    968      1.000000
    969      1.800000
    Name: OpenProfit, Length: 970, dtype: float64




```python
df.isnull().sum()
```




    Movie               0
    LeadStudio          0
    RottenTomatoes      0
    AudienceScore       0
    Story               0
    Genre               0
    TheatersOpenWeek    0
    OpeningWeekend      0
    BOAvgOpenWeekend    0
    DomesticGross       0
    ForeignGross        0
    WorldGross          0
    Budget              0
    Profitability       0
    OpenProfit          0
    Year                0
    dtype: int64




```python
df['ForeignGross'].replace(0,df['ForeignGross'].mean(),inplace=True)
```


```python
df[df['ForeignGross']==0]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Movie</th>
      <th>LeadStudio</th>
      <th>RottenTomatoes</th>
      <th>AudienceScore</th>
      <th>Story</th>
      <th>Genre</th>
      <th>TheatersOpenWeek</th>
      <th>OpeningWeekend</th>
      <th>BOAvgOpenWeekend</th>
      <th>DomesticGross</th>
      <th>ForeignGross</th>
      <th>WorldGross</th>
      <th>Budget</th>
      <th>Profitability</th>
      <th>OpenProfit</th>
      <th>Year</th>
    </tr>
  </thead>
  <tbody>
  </tbody>
</table>
</div>




```python
lab=df['Genre']
plt.figure(dpi=125)
plt.bar(x=df['Profitability'],height=lab,data=df)
plt.xlim(0,50)
```




    (0.0, 50.0)




    
![png](output_69_1.png)
    



```python
plt.figure(dpi=200)
sns.swarmplot(x=df['Genre'],y=df['Budget'],data=df)
plt.xlim(left=7)
```

    C:\ProgramData\Anaconda3\lib\site-packages\seaborn\categorical.py:1296: UserWarning: 51.2% of the points cannot be placed; you may want to decrease the size of the markers or use stripplot.
      warnings.warn(msg, UserWarning)
    C:\ProgramData\Anaconda3\lib\site-packages\seaborn\categorical.py:1296: UserWarning: 9.8% of the points cannot be placed; you may want to decrease the size of the markers or use stripplot.
      warnings.warn(msg, UserWarning)
    C:\ProgramData\Anaconda3\lib\site-packages\seaborn\categorical.py:1296: UserWarning: 10.0% of the points cannot be placed; you may want to decrease the size of the markers or use stripplot.
      warnings.warn(msg, UserWarning)
    C:\ProgramData\Anaconda3\lib\site-packages\seaborn\categorical.py:1296: UserWarning: 11.4% of the points cannot be placed; you may want to decrease the size of the markers or use stripplot.
      warnings.warn(msg, UserWarning)
    C:\ProgramData\Anaconda3\lib\site-packages\seaborn\categorical.py:1296: UserWarning: 80.9% of the points cannot be placed; you may want to decrease the size of the markers or use stripplot.
      warnings.warn(msg, UserWarning)
    C:\ProgramData\Anaconda3\lib\site-packages\seaborn\categorical.py:1296: UserWarning: 70.6% of the points cannot be placed; you may want to decrease the size of the markers or use stripplot.
      warnings.warn(msg, UserWarning)
    C:\ProgramData\Anaconda3\lib\site-packages\seaborn\categorical.py:1296: UserWarning: 14.3% of the points cannot be placed; you may want to decrease the size of the markers or use stripplot.
      warnings.warn(msg, UserWarning)
    C:\ProgramData\Anaconda3\lib\site-packages\seaborn\categorical.py:1296: UserWarning: 57.7% of the points cannot be placed; you may want to decrease the size of the markers or use stripplot.
      warnings.warn(msg, UserWarning)
    C:\ProgramData\Anaconda3\lib\site-packages\seaborn\categorical.py:1296: UserWarning: 20.0% of the points cannot be placed; you may want to decrease the size of the markers or use stripplot.
      warnings.warn(msg, UserWarning)
    C:\ProgramData\Anaconda3\lib\site-packages\seaborn\categorical.py:1296: UserWarning: 13.3% of the points cannot be placed; you may want to decrease the size of the markers or use stripplot.
      warnings.warn(msg, UserWarning)
    




    (7.0, 13.5)




    
![png](output_70_2.png)
    



```python

```


```python

```
